sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/f/library"
], function (Controller, fLibrary) {
  "use strict";

  return Controller.extend("zscort.compare.controller.App", {
    onStateChanged: function (oEvent) {
      var bIsNav = oEvent.getParameter("isNavigationArrow");
      var sLayout = oEvent.getParameter("layout");
      this.getOwnerComponent().getModel("appView").setProperty("/layout", sLayout);
      if (bIsNav) {
        // keep
      }
    }
  });
});
