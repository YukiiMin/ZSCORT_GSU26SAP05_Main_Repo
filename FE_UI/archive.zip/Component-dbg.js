sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/model/json/JSONModel",
  "sap/f/library",
  "sap/base/Log"
], function (UIComponent, JSONModel, fLibrary, Log) {
  "use strict";

  var LayoutType = fLibrary.LayoutType;

  return UIComponent.extend("zscort.compare.Component", {
    metadata: {
      manifest: "json"
    },

    init: function () {
      UIComponent.prototype.init.apply(this, arguments);

      var oAppModel = new JSONModel({
        layout: LayoutType.OneColumn,
        trkorr: "",
        serverId: "TGT",
        busy: false,
        filterStatus: "",
        compareMode: "L_VS_T",
        versionNo: "",
        versionNoRight: "99998",
        versions: [],
        // Chỉ đổi sau khi bấm Load
        noDataText: "Enter TR and press Load",
        hasLoaded: false
      });
      this.setModel(oAppModel, "appView");
      this.setModel(new JSONModel({}), "detail");

      try {
        this.getRouter().initialize();
      } catch (oErr) {
        Log.error("Router init failed", oErr, "zscort.compare.Component");
        throw oErr;
      }

      // F5 / hard reload: hash #/detail/... vẫn còn nhưng list TR mất (memory)
      // → luôn về Master 1 cột, tránh kẹt màn so sánh trống list
      this.getRouter().navTo("master", {}, true);
      oAppModel.setProperty("/layout", LayoutType.OneColumn);
    }
  });
});
